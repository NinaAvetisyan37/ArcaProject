import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:my_project/packages/home.dart';

main(){
  runApp(ArcaApp());
}
class ArcaApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),   
    ); 
  
  }

}