import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'pay.dart';
import '../packages/transfer.dart';
import '../packages/pay.dart';
import 'groups.dart';



class HomePage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _HomePage();
  
  }

}
class _HomePage extends State<HomePage> with SingleTickerProviderStateMixin{
  String title = 'Քարտեր';
  TabController tabController;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    tabController = TabController(length: 5, vsync: this,initialIndex: 2);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text(title), 
        elevation: 0,
        actions: [
          IconButton(icon: Icon(Icons.sort), onPressed: (){})
        ],

      ),
      body: body(),
    );
    
  }
Widget body(){
  return Column(
  
    children: [
      Card(
        margin: EdgeInsets.zero,
        elevation: 5,
        child: TabBar(
          indicatorPadding: EdgeInsets.zero,
          controller: tabController,
          labelColor: Theme.of(context).primaryColor,
          indicator: BoxDecoration(),
          labelPadding: EdgeInsets.zero,
          labelStyle: TextStyle(
            fontSize: 10
          ),
          unselectedLabelStyle: TextStyle(
             color: Theme.of(context).disabledColor,
            fontSize:10,
          ),
          unselectedLabelColor: Theme.of(context).disabledColor,
          tabs: [
          Tab(
            text:'Փոխանցել',
            icon: Icon(Icons.transform),
            
          ),
           Tab(
            text:'Վճարել',
            icon: Icon(Icons.account_balance_wallet),
            
          ),
            Tab(
              text:'Քարտեր',
              icon: Icon(Icons.credit_card),
            ),
             Tab(
              text:'Խմբեր',
              icon: Icon(Icons.folder_open),
            ),
             Tab(
              text:'Հաշիվ',
              icon: Icon(Icons.person_pin),
            ),
           
          ]
          ),
      ),
      Expanded(
              child: TabBarView(
          controller: tabController,
          children:[
            Transfer(),
            Pay(), 
            Text('data4'),
            Groups(),
            Text('data5'),
          ] 
          ),
      )
    ],
  );
}
}
