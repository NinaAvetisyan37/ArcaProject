

import 'dart:ui';

import 'package:flutter/material.dart';
import '../packages/home.dart';

class Transfer extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _Transfer();
  }
}
class _Transfer extends State<Transfer>{
  @override
  Widget build(BuildContext context) {
   return  Container(
    child: Column(
      mainAxisSize: MainAxisSize.min,
                     children: [
                       Container(
                         
                         height: 50,
                         color: Color.fromRGBO(220, 220, 220, 1),
                         
                         )
                     ],
    ),
  );
   
  }
  
}