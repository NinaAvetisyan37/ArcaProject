
import 'package:flutter/material.dart';
import 'home.dart';
class Pay extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _Pay();
  }
}
class _Pay extends State<Pay>{
  
  @override
  Widget build(BuildContext context) {  
   return Container(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                      child: Column(
                    children: [
                      Container(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                                 
                            children: [
                              
                               Icon(
                                 Icons.smartphone,
                                 color: Colors.lightBlue,
                                 ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Հեռախոսակապ',
                                style: TextStyle(
                                  fontSize:13
                                ),
                                ),
                              ),
                              
                            ],
                            
                          ),
                        ),
                        
                      ),
                     Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.bubble_chart,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'Կոմունալ վճարումներ',
                               style: TextStyle(
                                 fontSize:13
                               ),
                             
                             ),
                           ),
                            
                         ],
                       ),
                     ),
                       Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.tv,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'IP TV',
                               style: TextStyle(
                                 fontSize:13
                               ),
                               ),
                           ),
                            
                         ],
                       ),
                     ),
                     Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.router,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'Դոմոֆոն',
                               style: TextStyle(
                                 fontSize:13
                               ),
                               ),
                           ),
                            
                         ],
                       ),
                     ),
                     Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.tv,
                             color: Colors.lightBlue
                             ),
                           Text(
                             'Ինտերնետ',
                             style: TextStyle(
                               fontSize:13
                             ),
                             ),
                            
                         ],
                       ),
                     ),
                     Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.directions_car,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'ՃՈ տուգանքներ',
                               style: TextStyle(
                                 fontSize:13
                               ),
                               ),
                           ),
                            
                         ],
                       ),
                     ),
                     Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.local_parking,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'Ավտոկայանատեղ',
                               style: TextStyle(
                                 fontSize:13
                               ),
                               ),
                           ),
                            
                         ],
                       ),
                     ),
                     Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.home,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'Գույքահարկ',
                               style: TextStyle(
                                 fontSize:13
                               ),
                               ),
                           ),
                            
                         ],
                       ),
                     ),
                     Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.format_list_bulleted,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'Պետ.ծառայություններ',
                               style: TextStyle(
                                 fontSize:13
                               ),
                               ),
                           ),
                            
                         ],
                       ),
                     ),
                    Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: Row(
                         children: [
                           Icon(
                             Icons.format_list_bulleted,
                             color: Colors.lightBlue
                             ),
                           Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Text(
                               'Այլ ծառայություններ',
                               style: TextStyle(
                                 fontSize:13
                               ),
                               ),
                           ),
                            
                         ],
                       ),
                     ),
                  
                    ],
                  ),
                ),
              ),
              

              
              
             );
  }

}


  
