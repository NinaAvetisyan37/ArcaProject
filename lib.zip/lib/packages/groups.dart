import 'dart:ui';
import 'package:flutter/material.dart';
import 'home.dart';
class Groups extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _Groups();
  }
}
class _Groups extends State<Groups>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
  return Container(
    child: Column(
      children: [
        Form(
              child: Column(
                children: [
                  Row(
            children: [
                  Expanded(
                                  child: Padding(
                      padding: const EdgeInsets.fromLTRB(15, 0, 0, 0),
                      child: Container(
                        width: 290,
                        child: TextFormField(
                         decoration: InputDecoration(
                                hintText: "Որոնում",
                                hintStyle: TextStyle(
                                  fontSize:13,
                                  color: Colors.grey
                                )
                                
                              ),
                        ),
                      ),
                    ),
                  ),
                   Container(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 0, 15, 0),
                    child: Icon(
                      Icons.search,
                      color: Colors.grey
                      ),
                  )
           )
            ],
          ),
                ],
              ),
        ),
        Center(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(0, 40, 25, 0),
            child: Text('''
               Ավելացված խնբեր չկան:Կարող եք
           կազմել խմբեր ստեղծված էջանիշներից
               և կարգավորել դրանք`փոփոխել և 
            հեռացնել:Խումբը հեռացնելու դեպքում
           էջանիշները չեն հեռացվում:Ավելացնելու 
                            համար սեղմեք + կոճակը''',
                 style: TextStyle(
                   fontSize:12,
                   color: Colors.grey
                 )
                 ),
                 
          ),
          
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Icon(
            Icons.folder_open,
            color:Colors.lightBlue ,
            size: 100,
          ),
        ),
        // FloatingActionButton(
        //   onPressed: (){},
        //   child: Text('+'),
          
        //   backgroundColor: Colors.lightBlue
        //   )
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
          child: Row(
            mainAxisAlignment:MainAxisAlignment.end,
            children: [
              ClipOval(
  child: Material(
    color: Colors.lightBlue,
    child: InkWell(
      child: SizedBox(width: 40, height: 40, child: Icon(Icons.add,color: Colors.white,)),
      onTap: () {},
    ),
  ),
),
            ],
          ),
        )
      ],
    ),
    
     );
    
  

  }

}
   